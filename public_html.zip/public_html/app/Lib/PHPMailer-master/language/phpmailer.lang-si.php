<?php
/**
 * Sinhala PHPMailer language file: refer to English translation for definitive list
 * @package PHPMailer
 * @author Senasum Rajapalsha <senasum@live.com>
 */

$PHPMAILER_LANG['authenticate']         = 'SMTP fodihls: l%shd lrúh fkdyl .';
$PHPMAILER_LANG['connect_host']         = 'SMTP fodihls: iïnkao l, fkdyl.';
$PHPMAILER_LANG['data_not_accepted']    = 'SMTP fodihls: o;a; Ndr .; fkdyl.';
$PHPMAILER_LANG['empty_message']        = 'ysia mksúvhls';
$PHPMAILER_LANG['encoding']             = 'iqrlaYs; njg m;a lrï: ';
$PHPMAILER_LANG['execute']              = 'l%shd lrúh fkdyl: ';
$PHPMAILER_LANG['file_access']          = 'f.dkqj fj; ,.d úh fkdyl: ';
$PHPMAILER_LANG['file_open']            = 'f.dkqj újD; fkdfj: ';
$PHPMAILER_LANG['from_failed']          = 'f*d¾uh jrÈh: ';
$PHPMAILER_LANG['instantiate']          = 'jyd l, hq;= fj.';
$PHPMAILER_LANG['invalid_address']      = 'smskh jrÈh: ';
$PHPMAILER_LANG['mailer_not_supported'] = ' mksúv lre fkd.,mS.';
$PHPMAILER_LANG['provide_address']      = ',smskh w;=,a lrkak.';
$PHPMAILER_LANG['recipients_failed']    = 'SMTP fodihls: mksúvh ,.d l, fkdyl: ';
$PHPMAILER_LANG['signing']              = 'w;=,a úh fkdyl: ';
$PHPMAILER_LANG['smtp_connect_failed']  = 'SMTP iïnkao l, fkdyl.';
$PHPMAILER_LANG['smtp_error']           = 'SMTP fodihls:: ';
$PHPMAILER_LANG['variable_set']         = 'úp,h ilia lr fkdu;: ';
$PHPMAILER_LANG['extension_missing']    = 'l%shd lrúh fkdyl: ';
